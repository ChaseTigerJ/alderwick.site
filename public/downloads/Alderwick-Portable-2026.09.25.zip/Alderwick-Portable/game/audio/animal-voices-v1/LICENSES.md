# Animal sound credits

Edited for quiet interaction playback. All attribution is retained below.

- **Dog**: Brandon Morris (HaelDB), [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://opengameart.org/content/dog-barking-mono). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. 
- **Cat**: AntumDeluge, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://opengameart.org/content/kitten-mew). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. Original artist describes this as a performed kitten mew.
- **Sheep**: mikewest; edited by AntumDeluge, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://opengameart.org/content/sheep-baa). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. 
- **Duck**: OwennewO, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://freesound.org/people/OwennewO/sounds/719108/). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. 
- **Horse**: dobroide, [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/). [Original](https://freesound.org/people/dobroide/sounds/18229/). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. 
- **Chicken**: IMadeIt, [CC-BY-3.0](https://creativecommons.org/licenses/by/3.0/). [Original](https://opengameart.org/content/chicken-sound-effect). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. 
- **Deer**: dobroide, [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/). [Original](https://freesound.org/people/dobroide/sounds/104655/). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. 
