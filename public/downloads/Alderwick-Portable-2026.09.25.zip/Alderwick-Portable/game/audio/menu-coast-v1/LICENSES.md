# Alderwick menu music and coastal sounds

## Under Full Sail

Original composition and arrangement created for Alderwick: a 2:00, 48-bar chamber theme at 96 BPM. The performance is sequenced from recorded acoustic instruments, with phrasing, mild timing variation and a short chamber reverb. It is period-inspired rather than a historical reconstruction. No other game's music is included.

- **Versilian Community Sample Library (VCSL)**, **CC0 1.0**: recorded Baroque tenor recorder and English harpsichord, using its normal and lute stops. The lute stop is a harpsichord registration, not a separate lute recording. [Source and license](https://github.com/sgossner/VCSL).
- **VS Chamber Orchestra 2 Community Edition**, **CC0 1.0**: recorded solo violin, viola/cello sections and cello pizzicato. Samples by **Sam Gossner and Simon Dalzell**; sample cutting by **Elan Hickler / Soundemote**. [Publisher](https://versilian-studios.com/vsco-community/), [source and license](https://github.com/sgossner/VSCO-2-CE).
- The upstream license texts are included as `VCSL_CC0_LICENSE.txt` and `VSCO_CC0_LICENSE.txt`. [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).

Changes: source recordings were trimmed, modestly pitch-shifted between sampled notes, sequenced into the original score, given phrase envelopes and stereo placement, filtered, reverberated and mixed. Release and reverb tails wrap across the loop. The browser encodes use constant-gain mastering near -20 LUFS with ample peak headroom. This is not a live ensemble performance.

Pinned source revisions, paths, sounding note roots, Git blob hashes and source SHA-256 values are in `music-samples.json`. The editable composition, MIDI and renderer are retained in the project's `music/under-full-sail/` source directory. The former piano theme is retired from the current game package.

## Shore and breeze

Wave recordings: **jasinski**, extracted by **qubodup**, **CC0 1.0**.

- Source: https://opengameart.org/content/beach-ocean-waves
- Original field recording: https://freesound.org/people/jasinski/sounds/18363/
- License: https://creativecommons.org/publicdomain/zero/1.0/

Uses wave_01, wave_02 and wave_03. Edited with high/low-pass filtering, gentle soft limiting and continuous overlapping crossfades; level-smoothed into a 61-second circular stereo bed. The revised bed has no isolated wave events or silent gaps. A faint original filtered-noise breeze is mixed underneath. Encoded as Vorbis and MP3.

## Distant gulls

**Rango Mango**, Solo Seagull Sound Effects, **CC0 1.0**. Ambient clips 1 and 2.

- Source and permission declaration: https://opengameart.org/content/solo-seagull-sound-effects
- Recording linked by the uploader: https://www.youtube.com/watch?v=Nm4gg6GBBcc
- License: https://creativecommons.org/publicdomain/zero/1.0/

Changes: mono conversion, high/low-pass filtering, short fades, peak normalization and MP3 encoding. Played quietly, with mild stereo placement, after the opening melody and at irregular intervals of 45–80 seconds.

Retrieved September 19, 2026. Source URLs and SHA-256 checksums are in manifest.json. All audio is served with the game; no third-party audio service is contacted during playback.
