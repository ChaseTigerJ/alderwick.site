# Asset licenses

## Quaternius animals

The official Ultimate Animated Animal Pack page labels the pack CC0 and explicitly permits personal and commercial projects.

- Pack license declaration: https://quaternius.com/packs/ultimateanimatedanimals.html
- CC0 1.0 Universal deed: https://creativecommons.org/publicdomain/zero/1.0/
- CC0 legal text: https://creativecommons.org/publicdomain/zero/1.0/legalcode

The optimized GLBs inherit the source CC0 dedication. Attribution is not required by CC0; credit is retained in the game and repository for provenance.

These GLBs are retained but not loaded by the current renderer. The unified original animal models do not derive from these meshes or animation clips.

## Libraries and fonts

- Three.js: MIT, https://github.com/mrdoob/three.js/blob/dev/LICENSE
- React / React DOM: MIT, https://github.com/facebook/react/blob/main/LICENSE
- Lucide icons: ISC, https://github.com/lucide-icons/lucide/blob/main/LICENSE
- Vite: MIT, https://github.com/vitejs/vite/blob/main/LICENSE
- DM Sans: SIL Open Font License 1.1, https://github.com/google/fonts/tree/main/ofl/dmsans
- Libre Baskerville: SIL Open Font License 1.1, https://github.com/google/fonts/tree/main/ofl/librebaskerville

Dependency distributions retain their own license files. Fonts are requested from Google Fonts with local serif/sans fallbacks. The game does not rely on remote model URLs at runtime.

## Excluded assets and services

Quaternius Medieval Village MegaKit and Ultimate Nature Pack were researched but are not vendored. Kenney was considered as a secondary source but no Kenney files are included. No Tripo, Meshy, Unity Asset Store, or Stonehearth assets are included. No paid asset generation was submitted.

# Animal sound credits

Edited for quiet interaction playback. All attribution is retained below.

- **Dog**: Brandon Morris (HaelDB), [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://opengameart.org/content/dog-barking-mono). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3.
- **Cat**: AntumDeluge, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://opengameart.org/content/kitten-mew). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3. Original artist describes this as a performed kitten mew.
- **Sheep**: mikewest; edited by AntumDeluge, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://opengameart.org/content/sheep-baa). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3.
- **Duck**: OwennewO, [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Original](https://freesound.org/people/OwennewO/sounds/719108/). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3.
- **Horse**: dobroide, [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/). [Original](https://freesound.org/people/dobroide/sounds/18229/). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3.
- **Chicken**: IMadeIt, [CC-BY-3.0](https://creativecommons.org/licenses/by/3.0/). [Original](https://opengameart.org/content/chicken-sound-effect). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3.
- **Deer**: dobroide, [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/). [Original](https://freesound.org/people/dobroide/sounds/104655/). Excerpt, mono, normalized to -22 LUFS, faded and encoded MP3.

Wolf pack update (September 17, 2026): all new wolf geometry, combat animation, bandage geometry and blood effects are original project source, with no additional third-party license requirements.

## Launch interface assets

`src/ui/launch/HarborBackdrop.tsx` and `launch.css` contain original project artwork and animation. No additional third-party image/model license is required. `src/render/founderPreview.ts` reuses existing project geometry and the previously credited Three.js renderer.


The founding company update adds only original project geometry, palette data and SVG motifs. `bannerEmblem.ts`, `heraldry.ts`, and `firstPersonHands.ts` introduce no additional third-party asset license. Existing Three.js, Lucide and font licenses remain applicable.


## Harbor and everyday life update · September 18, 2026

The revised timber cottages, fully rigged menu merchant vessel, landing geometry and mountain silhouette are original SVG artwork. Jointed canine and workhorse meshes, idle poses, and resting-boat wavelets are original project source. `menuAudio.ts` contains an original composed theme rendered with procedural plucked-string and recorder-like synthesis, plus original interface tones. Spaced shore washes and timber creaks are generated in code. No external music, model, texture or new sound recording was downloaded; existing species recordings retain their credits above.

## Coastal piano menu update · September 19, 2026 (retired)

- **Salamander Grand Piano V3 samples by Alexander Holm:** [CC BY 3.0 Unported](https://creativecommons.org/licenses/by/3.0/). Adapted into the original track A Place to Return. The retired track and its full attribution remain in the source history; its samples are not used in the current menu track. [Source](https://sfzinstruments.github.io/pianos/salamander/).
- **Beach Ocean Waves by jasinski, extracted by qubodup:** [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Source/license declaration](https://opengameart.org/content/beach-ocean-waves).
- **Solo Seagull Sound Effects, Ambient 1 and 2, by Rango Mango:** [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). [Source/license and permission declaration](https://opengameart.org/content/solo-seagull-sound-effects).

All edits are documented in the shipped `audio/menu-coast-v1/LICENSES.md`, with source and output checksums in `manifest.json`. The original composition, breeze and interface tones are project work. No proprietary game soundtrack or paid generation service was used.

## Harbor, charter and credits update · September 19, 2026

The menu ship is rendered from Alderwick's original vessel mesh. The grazing deer uses an original faceted white-tailed buck model, with a jointed neck, ears and forked antlers. Its atlas, mooring and shore animations, settlement cottage preview, seven additional heraldic motifs, and Alderwick wordmark are original project work. No additional third-party artwork or animation is included.

The wordmark is a reusable SVG with system serif typography. The cottage preview is depth-rendered from the game's founder-home geometry, with a live nameplate and waving cloth that share the original camera projection. Stonehearth by Radiant Entertainment is acknowledged as a visual inspiration; no Stonehearth artwork, geometry, audio, code or branding is included.

Creator, game design and art direction: Chase Johnston. Engineering and original asset implementation: OpenAI Codex under Chase Johnston's direction. Copyright © 2026 Chase Johnston for original project content; third-party assets and software retain their respective licenses above.

## Period-inspired adventure menu · September 19, 2026

**Under Full Sail** replaces the retired piano theme. Original two-minute composition and sequenced arrangement for recorded Baroque tenor recorder, English harpsichord (normal and lute stops), solo violin, viola/cello sections and cello pizzicato. Instruments: [VCSL](https://github.com/sgossner/VCSL) and [VSCO 2 Community Edition](https://versilian-studios.com/vsco-community/), both **CC0 1.0**. VSCO recordings by Sam Gossner and Simon Dalzell, with sample cutting by Elan Hickler / Soundemote. This is a sampled performance, not a live ensemble recording.

Source modifications and license texts ship in `public/audio/menu-coast-v1/`; immutable source paths and checksums are in `music-samples.json`. The reproducible composition, renderer and editable MIDI are in `music/under-full-sail/`. Coastal field recordings keep their existing credits and mix. Playback still begins after the loading intro, with low default music gain and independent saved channel controls.
