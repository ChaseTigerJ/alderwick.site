# Alder Star menu vessel

`alder-star-lowpoly.webp` is an offline render of Alderwick's original
`vesselModel("barque")` geometry and materials in `src/render/vessels.ts`.
It follows the game's warm, low-poly miniature style rather than using
a separate painted interpretation. No third-party ship assets are included.

Rebuild with `node --import tsx scripts/menu-ship-render.ts` in the project root.
The script uses the project's CPU renderer and `@napi-rs/canvas`, available
through `CODEX_PRIMARY_RUNTIME_NODE_MODULES` or a local installation.
It renders at twice the shipping size for clean silhouettes and thin rigging.

`alder-star-lanterns.webp` is the matching depth-tested illumination pass.
Only visible lantern glass contributes; the original cages, hull and sails
occlude it. A subtle opacity animation lights those panes without repainting
or moving the ship's timberwork.

The menu moves the complete hull as one body, with restrained sailcloth
movement and a separate water reflection. Reduced-motion settings disable
both movements. The asset does not require a WebGL context in the menu.
